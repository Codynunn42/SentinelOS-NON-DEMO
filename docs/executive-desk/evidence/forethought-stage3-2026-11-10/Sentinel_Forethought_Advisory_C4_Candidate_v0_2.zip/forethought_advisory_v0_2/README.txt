SENTINEL FORETHOUGHT ADVISORY JOB — ISOLATED CANDIDATE v0.2

Implemented against SentinelOS-NON-DEMO main observed at
e1371a6a8d8e9f574e8703196061db359fe160c6. This is a local candidate package,
not a repository commit, deployment, approved runtime, or independent acceptance.

RUN (Node >=20, no dependency installation)
  node --test tests/advisory.test.js
  node scripts/check-archive-intelligence-docking.js
  node scripts/benchmark.js
The benchmark writes evidence locally. There are no network/API/model calls,
credentials, paid resources, worker threads, write-action tools or control hooks.

IMPLEMENTATION
apps/sentinel/src/archiveIntelligence/intakeRouter.js removes fixed May current
authority and static confidence. Historical paths are still discoverable. It uses
artifactPolicy.js to evaluate strict UTC lifecycle metadata, active version,
supersession and a trusted authority-registry binding. Missing/expired/unverified
records cannot fill CURRENT_AUTHORITY. Factual confidence is null/unassessed.
Freshness is the remaining validity fraction, not truth, probability or permission.
Exactly validUntil is still valid; timestamps later than validUntil are expired.

historicalReferences.js preserves legacy keyword/lane discovery without current
truth/approval assignments. analysis.js and forethought/interpretation.js are
unchanged pinned sources. The old docking test's assumptions are deliberately
updated: May keyword matches now require review and provide historical context.

advisoryJob.js runs Lens -> Sentinel -> Forethought -> Desk -> telemetry with
immutable stage snapshots. Lens discovers metadata only. Sentinel authenticates
through an injected trusted adapter, checks tenant/classification/read entitlement,
holds and content identity before fetching payloads. Retention alone doesn't deny
reading; an explicit read block or UNDER_HOLD does. Any blocked evidence halts the
job; receipts expose no source IDs/titles/content/hold vectors or partial packet.
Denial timing can still differ; constant-time noninterference is not claimed.

Authority is NOT established by a document declaring authorityLevel. A trusted
registry entry must bind its version, full-artifact digest and authority level.
The digest is not a signature. Live identity/signature verification and live policy
registry/storage adapters are NOT implemented. Fixture tokens are test identifiers
only. resolvePolicy/authenticate/store must not be populated from public request
parameters. intakeRouter.validatedArtifacts/authorityBindings are trusted internal
integration options, never caller-supplied assertions.

The deterministic Forethought adapter extracts structured source claims, validates
exact line quotes, detects conflicting values for identical subject/predicate keys,
lists required evidence gaps, and selects one useful next action. It does not infer
truth from a source claim or detect arbitrary natural-language contradictions.
Desk rechecks access/version/freshness before release and validates citations.
Signoff is pending human review and grants no execution; no UI or approval endpoint
is implemented. All output is advisory. Safe failure has no implicit fallback.

BENCHMARK BOUNDARY
100 synthetic cases, ten case kinds, ten repetitions, rotated arm order, one
excluded warmup pass. C1 is a static dump; C2 is metadata discovery; both are
unvalidated negative controls. C3 is synthesis from separately prevalidated input;
the 20 denied cases are skipped in C3. C4 is the complete local advisory pipeline.
There are 3,800 timed samples; 200 C3 skips are logged explicitly. All 1,000 C4
calls are timed: 800 review packets and 200 expected blocked receipts. No arm is a
Light candidate. C1/C2/C3 are not equivalent-capability speed comparisons with C4.

Outer latency includes the full function and JSON serialization, excluding fixture
setup, hashing and evidence-file writes. Stage telemetry uses boundary memory
samples and process.cpuUsage; total CPU includes instrumentation overhead. CPU
user/system microseconds, RSS and heap deltas are separate. Sampled maxima are NOT
true transient peaks; resourceUsage.maxRSS is a process-lifetime high-water mark.
Per-1,000 completed packet resource metrics exclude denials, also reported
separately. Endpoint-sampled RSS MB-hours are a coarse footprint estimate and
include shared runtime baseline memory. Process CPU seconds are not provisioned
vCPU-seconds, measured cycles or energy. Do not add CPU time and memory-time.
Energy/carbon remain UNKNOWN. CPU/memory improvements alone cannot prove greener.
Facility-level carbon-window scheduling requires telemetry, forecast provenance,
realized load/energy comparison, deadlines and service constraints; not tested here.

NEXT INTEGRATION
1. Review source.patch and changed legacy docking behavior on an isolated branch.
   The patch includes source and docking-check changes, not this package.json.
   This small package is runnable on its own; it is not a full repository checkout.
2. Bind trusted identity, policy and versioned evidence adapters. Verify signed
   authority provenance and live revocation semantics; no metadata self-grants.
3. Expand the corpus and freeze human-scored expected packets/claims/gaps.
4. Bind the separately reviewed real inference adapter, if the job requires it.
5. Re-establish complete-job baseline with real I/O before selecting acceleration.
   Light target: >=20% p50 improvement; no p95/p99 regression; complete invariant
   parity; resource budget predeclared. No Light or green pass is asserted here.

EVIDENCE
evidence/test-output.txt: 19 passing tests.
evidence/archive-docking-output.txt: updated docking regression passes.
evidence/benchmark.json: environment, input digest, arms, quantiles, stage/resource metrics.
evidence/samples.jsonl and skips.json: retained raw observations.
evidence/sample-*.json: advisory packet, conflict packet and redacted denial receipt.
SOURCE_BINDING.json / baseline/: pinned originals and source blob identity checks.
SHA256SUMS: archive contents identity. Local findings are not independent acceptance.
No governance disposition changes: GOV-001 Conditional; GOV-002 HOLD; GOV-006 open.
